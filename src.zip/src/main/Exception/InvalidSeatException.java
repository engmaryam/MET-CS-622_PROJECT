package src.main.Exception;
/*
 * Author Maryam95
 * Date 05/22/2023
 */
public class InvalidSeatException extends BusBookingException {
    public InvalidSeatException(String message) {
        super(message);
    }
}



