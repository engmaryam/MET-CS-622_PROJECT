package src.main.Exception;
/*
 * Author Maryam95
 * Date 05/22/2023
 */

public class BusBookingException extends Exception{

	 public BusBookingException(String message) {
	        super(message);
	    }
	}
